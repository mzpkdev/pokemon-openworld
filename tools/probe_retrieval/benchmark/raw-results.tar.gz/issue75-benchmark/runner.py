from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path

ROOT = Path("/home/mzpk/Workspace/pokemon-craze/tasks/issue-75-probe-retrieval/pokemon-openworld")
CORPUS = ROOT / "tools/probe_retrieval/benchmark/corpus.json"
SCHEMA = Path("/tmp/issue75-answer-schema.json")
OUTPUT = Path("/tmp/issue75-benchmark")
MODEL = "gpt-5.4"
REASONING = "low"
VARIANTS = {
    "control": (
        "Benchmark condition: control. Do not invoke tools.probe_retrieval or the cached "
        "Probe executable. Use only standard bounded repository tools such as rg and bounded "
        "file reads."
    ),
    "probe": (
        "Benchmark condition: probe. Use python3 -m tools.probe_retrieval.cli for supported "
        "C, C++, and Python retrieval when relevant. Use rg and bounded file reads for exact "
        "text and unsupported formats. Do not invoke raw Probe, MCP, Agent, or LSP."
    ),
}


def prompt(task: dict[str, object], variant: str) -> str:
    return "\n\n".join(
        (
            "This is a read-only repository retrieval benchmark. Do not modify files, use the "
            "network, or inspect sibling worktrees. Keep evidence bounded. Return only the "
            "requested JSON object.",
            VARIANTS[variant],
            f"Task id: {task['id']}",
            f"Task: {task['prompt']}",
        )
    )


def run(task: dict[str, object], variant: str) -> dict[str, object]:
    run_id = f"{task['id']}.{variant}"
    event_path = OUTPUT / "events" / f"{run_id}.jsonl"
    stderr_path = OUTPUT / "events" / f"{run_id}.stderr"
    command = [
        "codex",
        "exec",
        "--json",
        "--ephemeral",
        "--ignore-user-config",
        "-m",
        MODEL,
        "-c",
        f'model_reasoning_effort="{REASONING}"',
        "-s",
        "read-only",
        "-C",
        str(ROOT),
        "--output-schema",
        str(SCHEMA),
        prompt(task, variant),
    ]
    started = time.monotonic()
    completed = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=600,
        text=True,
    )
    latency = time.monotonic() - started
    event_path.write_text(completed.stdout, encoding="utf-8")
    stderr_path.write_text(completed.stderr, encoding="utf-8")
    usage = None
    answer = None
    tool_rounds = 0
    event_error = None
    for line in completed.stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            event_error = f"invalid JSONL event: {exc}"
            continue
        if event.get("type") == "turn.completed":
            usage = event.get("usage")
        if event.get("type") == "item.completed":
            item = event.get("item", {})
            if item.get("type") == "agent_message":
                try:
                    answer = json.loads(item.get("text", ""))
                except json.JSONDecodeError as exc:
                    event_error = f"invalid final answer JSON: {exc}"
            elif item.get("type") not in {"reasoning"}:
                tool_rounds += 1
    failure = event_error
    if completed.returncode != 0:
        failure = f"codex exit {completed.returncode}: {completed.stderr[-500:]}"
    if usage is None:
        failure = failure or "turn.completed usage missing"
    if answer is None:
        failure = failure or "agent answer missing"
    result = {
        "answer": answer,
        "condition_prompt": VARIANTS[variant],
        "failure": failure,
        "latency_seconds": round(latency, 3),
        "model": MODEL,
        "reasoning": REASONING,
        "returncode": completed.returncode,
        "run_id": run_id,
        "task_id": task["id"],
        "task_prompt": task["prompt"],
        "tool_rounds": tool_rounds,
        "usage": usage,
        "variant": variant,
    }
    print(
        json.dumps(
            {
                "run_id": run_id,
                "failure": failure,
                "latency_seconds": result["latency_seconds"],
                "tool_rounds": tool_rounds,
                "usage": usage,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return result


def main() -> None:
    OUTPUT.joinpath("events").mkdir(parents=True, exist_ok=True)
    corpus = json.loads(CORPUS.read_text(encoding="utf-8"))
    results = []
    for index, task in enumerate(corpus["tasks"]):
        order = ("control", "probe") if index % 2 == 0 else ("probe", "control")
        for variant in order:
            results.append(run(task, variant))
    document = {
        "cache_condition": (
            "ephemeral Codex session per run; no Probe session cache; alternating pair order; "
            "operating-system and server prompt caches left enabled and measured"
        ),
        "model": MODEL,
        "reasoning": REASONING,
        "results": results,
        "schema_version": 1,
        "worktree_revision": subprocess.run(
            ("git", "rev-parse", "HEAD"),
            cwd=ROOT,
            check=True,
            stdout=subprocess.PIPE,
            text=True,
        ).stdout.strip(),
    }
    OUTPUT.joinpath("results.json").write_text(
        json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
